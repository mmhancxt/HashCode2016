//
//  main.cpp
//  HashCode2016
//
//  Created by Liang LIU on 16/01/2016.
//  Copyright (c) 2016 Liang LIU. All rights reserved.
//
#include <iostream>
#include "InputLoader.h"
#include "DeliveryByProduct.h"

using namespace std;

int main(int argc, const char * argv[]) {

//	string fileName = "C:\\HashCode2016\\HashCode2016\\code\\mother_of_all_warehouses.in";
//	InputLoader loader;
//	loader.LoadFromFile(fileName);
    DeliveryByProduct dbp;
    dbp.Start();
	return 0;
}

